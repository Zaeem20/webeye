from .core import *

__name__ = "webeye"
__version__ = "2.1.6"
__author__ = "Zaeem Technical"
__helper__ = "Rishi Raj"
__github__ = "https://github.com/Zaeem20/webeye/"
__licence__ = "MIT"
__all__ = ["Webeye", "__name__", "__version__", "__author__", "__helper__","__github__","__license__"]

